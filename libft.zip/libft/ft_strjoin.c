/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gfurtado <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/26 14:29:20 by gfurtado          #+#    #+#             */
/*   Updated: 2022/11/26 14:30:19 by gfurtado         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strjoin(char const *s1, char const *s2)
{
	int		i;
	int		ii;
	char	*str;
	char	*str2;

	str2 = (char *)s2;
	str = (char *)malloc(sizeof(char) * ft_strlen(s1) + ft_strlen(s2) + 1);
	if (!str)
		return (NULL);
	if (!s1)
		return ((char *)s1);
	i = 0;
	while (s1[i])
	{
		str[i] = s1[i];
		i++;
	}
	ii = 0;
	while (str2[ii])
	{
		str[i++] = str2[ii++];
	}
	str[i] = '\0';
	return (str);
}
